# Keep-alive setup (free)

Supabase's free projects pause after 7 days with no activity. This weekly ping prevents that.

## Option 1: GitHub Actions (recommended, free)

1. Create a free GitHub account if you don't have one, then create a new private repository called `ofefit-backend`.
2. Upload the `ofefit-backend` folder to it (including the `.github` folder).
3. In the repository, go to Settings > Secrets and variables > Actions, and add two secrets:
   - `SUPABASE_URL`: from Supabase > Project Settings > API > Project URL
   - `SUPABASE_ANON_KEY`: from the same page, the "anon public" key
4. Go to the Actions tab, open "ofefit keep-alive", and click "Run workflow" once to test it.
   A green tick means the ping worked.

After that it runs every Monday on its own.

## Option 2: cron-job.org (if you'd rather not use GitHub)

1. Create a free account at cron-job.org.
2. Create a job that sends a POST request to:
   `YOUR_SUPABASE_URL/rest/v1/rpc/keep_alive`
   with the headers `apikey` and `Authorization: Bearer` set to your anon key, and `Content-Type: application/json`.
   The body should be `{}`.
3. Set it to run once a week.

## Keys: keep them private

Only use the anon key for these pings and the website. Never put the `service_role` key anywhere
public, in the repository or on the website.
