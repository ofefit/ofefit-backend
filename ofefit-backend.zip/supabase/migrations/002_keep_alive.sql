-- Lightweight function the weekly keep-alive ping calls so the free project stays active.
create or replace function public.keep_alive() returns timestamptz
language sql stable as $$ select now(); $$;

grant execute on function public.keep_alive() to anon, authenticated;
