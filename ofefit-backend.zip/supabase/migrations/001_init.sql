-- ofefit: database schema, security rules and functions
-- Run once in the Supabase SQL editor (or as a migration).

create extension if not exists pgcrypto;

-- ---------- Types ----------
create type membership_tier as enum ('student','weekend','flex','core','founders','family','annual');
create type member_status   as enum ('pending','active','expired','cancelled');
create type payment_status  as enum ('pending','confirmed','rejected');

-- ---------- Tables ----------
create table public.members (
  code          text primary key check (code ~ '^FIE-[A-Z0-9]{6}$'),
  full_name     text not null,
  phone         text not null,
  tier          membership_tier not null,
  price_ghs     integer not null,
  student_id    text,
  children      smallint check (children between 0 and 2),
  status        member_status not null default 'pending',
  joined_at     timestamptz not null default now(),
  expires_at    timestamptz,
  last_paid_at  timestamptz
);

create table public.payments (
  id            uuid primary key default gen_random_uuid(),
  member_code   text not null references public.members(code) on delete cascade,
  tier          membership_tier not null,
  amount_ghs    integer not null,
  momo_txn_id   text not null,
  status        payment_status not null default 'pending',
  created_at    timestamptz not null default now(),
  confirmed_at  timestamptz,
  confirmed_by  uuid references auth.users(id)
);
create unique index payments_txn_unique on public.payments (momo_txn_id);

create table public.checkins (
  id             uuid primary key default gen_random_uuid(),
  member_code    text not null references public.members(code) on delete cascade,
  session_key    text not null check (session_key in ('tue','thu','sat','walk','big')),
  checkin_date   date not null default ((now() at time zone 'Africa/Accra')::date),
  checked_in_at  timestamptz not null default now(),
  checked_by     uuid references auth.users(id),
  unique (member_code, session_key, checkin_date)
);

create table public.staff (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  full_name  text,
  role       text not null default 'gate' check (role in ('owner','admin','gate'))
);

-- ---------- Role helpers ----------
create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff where user_id = auth.uid());
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff where user_id = auth.uid() and role in ('owner','admin'));
$$;

-- ---------- Row level security ----------
-- Nobody can read or write these tables directly from the browser.
-- Staff read through the policies below; everything else goes through functions.
alter table public.members  enable row level security;
alter table public.payments enable row level security;
alter table public.checkins enable row level security;
alter table public.staff    enable row level security;

create policy staff_read_members  on public.members  for select using (public.is_staff());
create policy admin_update_members on public.members for update using (public.is_admin()) with check (public.is_admin());
create policy admin_read_payments on public.payments for select using (public.is_admin());
create policy staff_read_checkins on public.checkins for select using (public.is_staff());
create policy admin_read_staff    on public.staff     for select using (public.is_admin());

-- ---------- Public functions (no login needed) ----------
create or replace function public.join_membership(
  p_name text, p_phone text, p_tier membership_tier,
  p_student_id text default null, p_children smallint default 0
) returns table(member_code text, amount_ghs integer)
language plpgsql security definer set search_path = public as $$
declare
  v_code  text;
  v_price integer;
  v_taken integer;
begin
  if length(trim(p_name)) < 2 or length(trim(p_phone)) < 9 then
    raise exception 'Name and phone number are required';
  end if;
  if p_tier = 'student' and coalesce(trim(p_student_id), '') = '' then
    raise exception 'A UCC student ID is required for the student membership';
  end if;
  if p_tier = 'founders' then
    select count(*) into v_taken from public.members where tier = 'founders';
    if v_taken >= 25 then raise exception 'Founders Core is full'; end if;
  end if;

  v_price := case p_tier
    when 'student' then 60  when 'weekend' then 45 when 'flex' then 90
    when 'core' then 120    when 'founders' then 100 when 'family' then 200
    when 'annual' then 1200 end;

  loop
    v_code := 'FIE-' || upper(substr(encode(gen_random_bytes(4), 'hex'), 1, 6));
    exit when not exists (select 1 from public.members where code = v_code);
  end loop;

  insert into public.members (code, full_name, phone, tier, price_ghs, student_id, children)
  values (
    v_code, trim(p_name), trim(p_phone), p_tier, v_price,
    nullif(trim(coalesce(p_student_id, '')), ''),
    case when p_tier = 'family' then p_children else null end
  );

  return query select v_code, v_price;
end $$;

create or replace function public.get_member_card(p_code text)
returns table(full_name text, tier membership_tier, status member_status, expires_at timestamptz)
language sql stable security definer set search_path = public as $$
  select m.full_name, m.tier, m.status, m.expires_at
  from public.members m
  where m.code = upper(trim(p_code));
$$;

create or replace function public.submit_payment(p_code text, p_txn text)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  m    public.members%rowtype;
  v_id uuid;
begin
  select * into m from public.members where code = upper(trim(p_code));
  if not found then raise exception 'Unknown member code'; end if;
  if length(trim(coalesce(p_txn, ''))) < 4 then raise exception 'Enter the MoMo transaction ID'; end if;

  insert into public.payments (member_code, tier, amount_ghs, momo_txn_id)
  values (m.code, m.tier, m.price_ghs, trim(p_txn))
  returning id into v_id;
  return v_id;
exception when unique_violation then
  raise exception 'This MoMo transaction ID has already been submitted';
end $$;

-- ---------- Staff functions ----------
create or replace function public.confirm_payment(p_payment uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  p    public.payments%rowtype;
  v_days integer;
begin
  if not public.is_admin() then raise exception 'Not authorised'; end if;

  select * into p from public.payments where id = p_payment for update;
  if not found then raise exception 'Payment not found'; end if;
  if p.status <> 'pending' then raise exception 'Payment has already been handled'; end if;

  v_days := case when p.tier = 'annual' then 365 else 30 end;

  update public.payments
     set status = 'confirmed', confirmed_at = now(), confirmed_by = auth.uid()
   where id = p_payment;

  -- Renewals extend from the current expiry date, not from today.
  update public.members
     set status = 'active',
         expires_at = greatest(coalesce(expires_at, now()), now()) + make_interval(days => v_days),
         last_paid_at = now()
   where code = p.member_code;
end $$;

create or replace function public.check_in(p_code text, p_session text) returns text
language plpgsql security definer set search_path = public as $$
declare
  m public.members%rowtype;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;

  select * into m from public.members where code = upper(trim(p_code));
  if not found then return 'unknown'; end if;
  if m.status <> 'active' or m.expires_at is null or m.expires_at <= now() then
    return 'inactive';
  end if;

  insert into public.checkins (member_code, session_key, checked_by)
  values (m.code, p_session, auth.uid())
  on conflict (member_code, session_key, checkin_date) do nothing;

  if not found then return 'duplicate'; end if;
  return 'ok';
end $$;

create or replace function public.revenue_summary(p_from timestamptz, p_to timestamptz)
returns table(tier membership_tier, payments bigint, revenue bigint)
language sql stable security definer set search_path = public as $$
  select p.tier, count(*), sum(p.amount_ghs)::bigint
  from public.payments p
  where public.is_admin()
    and p.status = 'confirmed'
    and p.confirmed_at >= p_from and p.confirmed_at < p_to
  group by p.tier;
$$;

-- ---------- Permissions ----------
revoke all on function public.join_membership(text, text, membership_tier, text, smallint) from public;
revoke all on function public.get_member_card(text)  from public;
revoke all on function public.submit_payment(text, text) from public;
grant execute on function public.join_membership(text, text, membership_tier, text, smallint) to anon, authenticated;
grant execute on function public.get_member_card(text)  to anon, authenticated;
grant execute on function public.submit_payment(text, text) to anon, authenticated;
grant execute on function public.confirm_payment(uuid) to authenticated;
grant execute on function public.check_in(text, text) to authenticated;
grant execute on function public.revenue_summary(timestamptz, timestamptz) to authenticated;
grant execute on function public.is_staff() to authenticated;
grant execute on function public.is_admin() to authenticated;
